# RestedXP Guides

## Overview

This is a platform to write in-game leveling guides for WoW Classic

## Writing your own guides

If you wish to create your own guides using this platform you can check out this article:
https://www.restedxp.com/create-your-own-restedxp-guide/

